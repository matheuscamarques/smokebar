 
   <?php //Cabeçalho da Página
    require_once "./estruturas/header.php"  ?>

    <?php  //Arquvio de menu
    require_once "./estruturas/menu.html" ?>

    <?php //Arquivo conteudo da página dinamica(./articles)
    require_once "./estruturas/controlador.php"  ?>

    <?php // Arquivo footer
    require_once "./estruturas/footer.html"; ?>