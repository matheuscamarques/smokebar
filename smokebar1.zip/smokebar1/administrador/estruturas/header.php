<!DOCTYPE html>
<html lang="en">
<?php //Esse arquivo se refere ao Programa 1 
?>

<head>
    <title>Administrador</title>

    <?php
    //Pega as dependencias de cabeçalhos na pasta assets/header
    require_once "../assets/header.php";
    //Busca pelos styles sheets em geral (só faz a linkagem), tomar cuidado com nomes de id e class , nomes iguais recebem o mesmo tratamento.
    require_once "../assets/stylesheet.php";
    ?>

</head>



<body>