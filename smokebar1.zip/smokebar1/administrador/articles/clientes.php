<div class="jumbotron">
    <div class="container text-rigth">
        <h1>Clientes</h1>
        <p>Quem são nossos clientes?</p>
    </div>
</div>

<iframe width="100%" height="400px" scrolling="no" border="0" frameborder="0" src="./backclientes/view_pesquisar.php"> </iframe>